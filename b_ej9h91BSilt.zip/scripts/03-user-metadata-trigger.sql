-- Criar função para criar metadata automaticamente quando um usuário é criado
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.users_metadata (user_id, company_name, role, industry, company_size, onboarding_completed)
  values (
    new.id,
    '',
    '',
    '',
    '',
    false
  )
  on conflict (user_id) do nothing;

  return new;
end;
$$;

-- Remover trigger antigo se existir
drop trigger if exists on_auth_user_created on auth.users;

-- Criar trigger que executa quando um usuário é criado
create trigger on_auth_user_created
  after insert on auth.users
  for each row
  execute function public.handle_new_user();
