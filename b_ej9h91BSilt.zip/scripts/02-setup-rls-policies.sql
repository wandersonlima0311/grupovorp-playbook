-- ==============================================================================
-- PLAYBOOK COMERCIAL INTELIGENTE - ROW LEVEL SECURITY POLICIES
-- ==============================================================================
-- Este script configura as políticas de segurança RLS no Supabase
-- Garante que usuários só podem acessar seus próprios dados

-- ==============================================================================
-- ATIVAR RLS EM TODAS AS TABELAS
-- ==============================================================================
ALTER TABLE users_metadata ENABLE ROW LEVEL SECURITY;
ALTER TABLE playbooks ENABLE ROW LEVEL SECURITY;
ALTER TABLE playbook_versions ENABLE ROW LEVEL SECURITY;

-- ==============================================================================
-- POLICIES: users_metadata
-- ==============================================================================

-- Usuários podem ver apenas seus próprios dados
DROP POLICY IF EXISTS "Users can view own metadata" ON users_metadata;
CREATE POLICY "Users can view own metadata"
  ON users_metadata
  FOR SELECT
  USING (auth.uid() = id);

-- Usuários podem inserir seus próprios dados (durante cadastro)
DROP POLICY IF EXISTS "Users can insert own metadata" ON users_metadata;
CREATE POLICY "Users can insert own metadata"
  ON users_metadata
  FOR INSERT
  WITH CHECK (auth.uid() = id);

-- Usuários podem atualizar seus próprios dados
DROP POLICY IF EXISTS "Users can update own metadata" ON users_metadata;
CREATE POLICY "Users can update own metadata"
  ON users_metadata
  FOR UPDATE
  USING (auth.uid() = id)
  WITH CHECK (auth.uid() = id);

-- Usuários podem deletar seus próprios dados
DROP POLICY IF EXISTS "Users can delete own metadata" ON users_metadata;
CREATE POLICY "Users can delete own metadata"
  ON users_metadata
  FOR DELETE
  USING (auth.uid() = id);

-- ==============================================================================
-- POLICIES: playbooks
-- ==============================================================================

-- Usuários podem ver apenas seus próprios playbooks
DROP POLICY IF EXISTS "Users can view own playbooks" ON playbooks;
CREATE POLICY "Users can view own playbooks"
  ON playbooks
  FOR SELECT
  USING (auth.uid() = user_id);

-- Usuários podem criar playbooks
DROP POLICY IF EXISTS "Users can create playbooks" ON playbooks;
CREATE POLICY "Users can create playbooks"
  ON playbooks
  FOR INSERT
  WITH CHECK (auth.uid() = user_id);

-- Usuários podem atualizar apenas seus próprios playbooks
DROP POLICY IF EXISTS "Users can update own playbooks" ON playbooks;
CREATE POLICY "Users can update own playbooks"
  ON playbooks
  FOR UPDATE
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Usuários podem deletar apenas seus próprios playbooks
DROP POLICY IF EXISTS "Users can delete own playbooks" ON playbooks;
CREATE POLICY "Users can delete own playbooks"
  ON playbooks
  FOR DELETE
  USING (auth.uid() = user_id);

-- ==============================================================================
-- POLICIES: playbook_versions
-- ==============================================================================

-- Usuários podem ver versões de seus próprios playbooks
DROP POLICY IF EXISTS "Users can view own playbook versions" ON playbook_versions;
CREATE POLICY "Users can view own playbook versions"
  ON playbook_versions
  FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM playbooks
      WHERE playbooks.id = playbook_versions.playbook_id
      AND playbooks.user_id = auth.uid()
    )
  );

-- Usuários podem criar versões de seus próprios playbooks
DROP POLICY IF EXISTS "Users can create playbook versions" ON playbook_versions;
CREATE POLICY "Users can create playbook versions"
  ON playbook_versions
  FOR INSERT
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM playbooks
      WHERE playbooks.id = playbook_versions.playbook_id
      AND playbooks.user_id = auth.uid()
    )
  );

-- Usuários podem deletar versões de seus próprios playbooks
DROP POLICY IF EXISTS "Users can delete own playbook versions" ON playbook_versions;
CREATE POLICY "Users can delete own playbook versions"
  ON playbook_versions
  FOR DELETE
  USING (
    EXISTS (
      SELECT 1 FROM playbooks
      WHERE playbooks.id = playbook_versions.playbook_id
      AND playbooks.user_id = auth.uid()
    )
  );

-- ==============================================================================
-- CONFIRMAÇÃO
-- ==============================================================================
DO $$
BEGIN
  RAISE NOTICE '✓ Row Level Security (RLS) policies created successfully!';
  RAISE NOTICE '✓ RLS enabled on all tables';
  RAISE NOTICE '✓ Users can only access their own data';
  RAISE NOTICE '✓ Security policies applied to: users_metadata, playbooks, playbook_versions';
  RAISE NOTICE 'Database setup is now complete and secure!';
END $$;
