-- ==============================================================================
-- PLAYBOOK COMERCIAL INTELIGENTE - DATABASE SETUP
-- ==============================================================================
-- Este script cria as tabelas necessárias para o sistema de geração de playbooks

-- ==============================================================================
-- TABELA: users_metadata
-- Armazena informações adicionais dos usuários (complementa auth.users do Supabase)
-- ==============================================================================
CREATE TABLE IF NOT EXISTS users_metadata (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  nome_completo TEXT NOT NULL,
  nome_empresa TEXT NOT NULL,
  faturamento_mensal TEXT NOT NULL CHECK (faturamento_mensal IN ('ate_10k', '10k_50k', '50k_100k', '100k_mais')),
  telefone TEXT NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Índice para melhorar performance de queries
CREATE INDEX IF NOT EXISTS idx_users_metadata_id ON users_metadata(id);

-- Comentários para documentação
COMMENT ON TABLE users_metadata IS 'Dados complementares dos usuários do sistema';
COMMENT ON COLUMN users_metadata.faturamento_mensal IS 'Faixa de faturamento mensal da empresa';

-- ==============================================================================
-- TABELA: playbooks
-- Armazena os playbooks criados pelos usuários
-- ==============================================================================
CREATE TABLE IF NOT EXISTS playbooks (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  nome_playbook TEXT NOT NULL,
  dados_input JSONB NOT NULL,
  conteudo_gerado TEXT,
  status TEXT DEFAULT 'draft' CHECK (status IN ('draft', 'generating', 'completed', 'error')),
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Índices para otimização de queries
CREATE INDEX IF NOT EXISTS idx_playbooks_user_id ON playbooks(user_id);
CREATE INDEX IF NOT EXISTS idx_playbooks_created_at ON playbooks(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_playbooks_status ON playbooks(status);

-- Comentários para documentação
COMMENT ON TABLE playbooks IS 'Playbooks comerciais gerados pelo sistema';
COMMENT ON COLUMN playbooks.dados_input IS 'Dados do formulário em formato JSON';
COMMENT ON COLUMN playbooks.conteudo_gerado IS 'Conteúdo do playbook em Markdown';
COMMENT ON COLUMN playbooks.status IS 'Status: draft, generating, completed, error';

-- ==============================================================================
-- TABELA: playbook_versions
-- Armazena histórico de versões dos playbooks (quando regenerados)
-- ==============================================================================
CREATE TABLE IF NOT EXISTS playbook_versions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  playbook_id UUID NOT NULL REFERENCES playbooks(id) ON DELETE CASCADE,
  version_number INTEGER NOT NULL,
  dados_input JSONB NOT NULL,
  conteudo_gerado TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Índice para buscar versões por playbook
CREATE INDEX IF NOT EXISTS idx_playbook_versions_playbook_id ON playbook_versions(playbook_id);
CREATE INDEX IF NOT EXISTS idx_playbook_versions_playbook_version ON playbook_versions(playbook_id, version_number DESC);

-- Comentários para documentação
COMMENT ON TABLE playbook_versions IS 'Histórico de versões de playbooks regenerados';
COMMENT ON COLUMN playbook_versions.version_number IS 'Número sequencial da versão';

-- ==============================================================================
-- FUNÇÃO: Atualizar updated_at automaticamente
-- ==============================================================================
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Trigger para atualizar updated_at em users_metadata
DROP TRIGGER IF EXISTS update_users_metadata_updated_at ON users_metadata;
CREATE TRIGGER update_users_metadata_updated_at
  BEFORE UPDATE ON users_metadata
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- Trigger para atualizar updated_at em playbooks
DROP TRIGGER IF EXISTS update_playbooks_updated_at ON playbooks;
CREATE TRIGGER update_playbooks_updated_at
  BEFORE UPDATE ON playbooks
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- ==============================================================================
-- CONFIRMAÇÃO
-- ==============================================================================
DO $$
BEGIN
  RAISE NOTICE '✓ Database setup completed successfully!';
  RAISE NOTICE '✓ Tables created: users_metadata, playbooks, playbook_versions';
  RAISE NOTICE '✓ Indexes created for performance optimization';
  RAISE NOTICE '✓ Triggers created for auto-updating timestamps';
  RAISE NOTICE 'Next step: Run 02-setup-rls-policies.sql to enable Row Level Security';
END $$;
