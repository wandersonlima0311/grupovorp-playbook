import { Card, CardContent } from '@/components/ui/card'
import { BookOpen, CheckCircle2, FileText } from 'lucide-react'

interface DashboardStatsProps {
  stats: {
    totalPlaybooks: number
    completedPlaybooks: number
    draftPlaybooks: number
  }
}

export function DashboardStats({ stats }: DashboardStatsProps) {
  const statItems = [
    {
      label: 'Total de Playbooks',
      value: stats.totalPlaybooks,
      icon: BookOpen,
      color: 'text-primary',
    },
    {
      label: 'Concluídos',
      value: stats.completedPlaybooks,
      icon: CheckCircle2,
      color: 'text-primary',
    },
    {
      label: 'Rascunhos',
      value: stats.draftPlaybooks,
      icon: FileText,
      color: 'text-muted-foreground',
    },
  ]

  return (
    <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
      {statItems.map((item) => {
        const Icon = item.icon
        return (
          <Card key={item.label} className="border-border/50 bg-card/50 backdrop-blur">
            <CardContent className="flex items-center gap-4 p-6">
              <div className={`rounded-lg bg-primary/10 p-3 ${item.color}`}>
                <Icon className="h-6 w-6" />
              </div>
              <div>
                <p className="text-sm font-medium text-muted-foreground">{item.label}</p>
                <p className="text-3xl font-bold tracking-tight text-foreground">
                  {item.value}
                </p>
              </div>
            </CardContent>
          </Card>
        )
      })}
    </div>
  )
}
