import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Plus, Sparkles } from 'lucide-react'

export function EmptyState() {
  return (
    <Card className="border-dashed border-2">
      <CardContent className="flex flex-col items-center justify-center py-16 text-center">
        <div className="rounded-full bg-primary/10 p-6 mb-4">
          <Sparkles className="h-12 w-12 text-primary" />
        </div>
        <h3 className="text-2xl font-bold tracking-tight mb-2">
          Nenhum playbook criado ainda
        </h3>
        <p className="text-muted-foreground max-w-md mb-8">
          Crie seu primeiro playbook comercial personalizado com inteligência artificial.
          Responda algumas perguntas e receba um guia completo em minutos.
        </p>
        <Button asChild size="lg">
          <Link href="/playbook/novo">
            <Plus className="mr-2 h-5 w-5" />
            Criar Primeiro Playbook
          </Link>
        </Button>
      </CardContent>
    </Card>
  )
}
