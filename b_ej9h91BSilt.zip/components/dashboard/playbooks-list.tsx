'use client'

import { useState } from 'react'
import Link from 'next/link'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import { MoreVertical, Eye, Trash2, FileText, Plus } from 'lucide-react'
import { deletePlaybook } from '@/app/actions/playbooks'
import { useRouter } from 'next/navigation'
import type { Playbook } from '@/lib/types/database'

interface PlaybooksListProps {
  playbooks: Playbook[]
}

export function PlaybooksList({ playbooks }: PlaybooksListProps) {
  const router = useRouter()
  const [deletingId, setDeletingId] = useState<string | null>(null)

  const handleDelete = async (playbookId: string) => {
    if (!confirm('Tem certeza que deseja excluir este playbook?')) return

    setDeletingId(playbookId)
    await deletePlaybook(playbookId)
    router.refresh()
  }

  const formatDate = (date: string) => {
    return new Date(date).toLocaleDateString('pt-BR', {
      day: '2-digit',
      month: 'short',
      year: 'numeric',
    })
  }

  return (
    <div>
      <div className="mb-6 flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold tracking-tight text-foreground">
            Seus Playbooks
          </h2>
          <p className="text-sm text-muted-foreground">
            Gerencie e acesse seus playbooks comerciais
          </p>
        </div>
        <Button asChild>
          <Link href="/playbook/novo">
            <Plus className="mr-2 h-4 w-4" />
            Novo Playbook
          </Link>
        </Button>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {playbooks.map((playbook) => (
          <Card
            key={playbook.id}
            className="group relative border-border/50 bg-card/50 backdrop-blur transition-all hover:border-primary/50 hover:shadow-lg"
          >
            <CardHeader className="pb-3">
              <div className="flex items-start justify-between">
                <FileText className="h-8 w-8 text-primary" />
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-8 w-8 opacity-0 transition-opacity group-hover:opacity-100"
                    >
                      <MoreVertical className="h-4 w-4" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    <DropdownMenuItem asChild>
                      <Link href={`/playbook/${playbook.id}`}>
                        <Eye className="mr-2 h-4 w-4" />
                        Visualizar
                      </Link>
                    </DropdownMenuItem>
                    <DropdownMenuItem
                      onClick={() => handleDelete(playbook.id)}
                      disabled={deletingId === playbook.id}
                      className="text-destructive focus:text-destructive"
                    >
                      <Trash2 className="mr-2 h-4 w-4" />
                      Excluir
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>
            </CardHeader>
            <CardContent>
              <CardTitle className="mb-2 line-clamp-1 text-lg">
                {playbook.title}
              </CardTitle>
              <CardDescription className="mb-4 text-sm">
                Atualizado em {formatDate(playbook.updated_at)}
              </CardDescription>
              <div className="flex items-center justify-between">
                <Badge
                  variant={playbook.status === 'completed' ? 'default' : 'secondary'}
                >
                  {playbook.status === 'completed' ? 'Concluído' : 'Rascunho'}
                </Badge>
                <Button variant="ghost" size="sm" asChild>
                  <Link href={`/playbook/${playbook.id}`}>
                    Abrir
                  </Link>
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}
