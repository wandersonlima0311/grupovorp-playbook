'use client'

import { cn } from '@/lib/utils'

interface PlaybookTableOfContentsProps {
  sections: Array<{ id: string; title: string }>
  activeSection: string | null
  onSectionClick: (id: string) => void
}

export function PlaybookTableOfContents({
  sections,
  activeSection,
  onSectionClick,
}: PlaybookTableOfContentsProps) {
  const handleClick = (id: string) => {
    onSectionClick(id)
    const element = document.getElementById(`section-${id}`)
    if (element) {
      element.scrollIntoView({ behavior: 'smooth', block: 'start' })
    }
  }

  return (
    <nav className="space-y-1">
      {sections.map((section, index) => (
        <button
          key={section.id}
          onClick={() => handleClick(section.id)}
          className={cn(
            'w-full text-left px-3 py-2 rounded-md text-sm transition-colors',
            'hover:bg-accent hover:text-accent-foreground',
            activeSection === section.id
              ? 'bg-primary/10 text-primary font-medium'
              : 'text-muted-foreground'
          )}
        >
          <div className="flex items-start gap-2">
            <span className="text-xs mt-0.5 font-mono opacity-60">
              {String(index + 1).padStart(2, '0')}
            </span>
            <span className="flex-1 leading-tight">{section.title}</span>
          </div>
        </button>
      ))}
    </nav>
  )
}
