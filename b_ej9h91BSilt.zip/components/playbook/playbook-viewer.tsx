'use client'

import { useState } from 'react'
import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import {
  ArrowLeft,
  Download,
  RefreshCw,
  BookOpen,
  Clock,
} from 'lucide-react'
import { PlaybookTableOfContents } from './playbook-toc'
import { PlaybookContent } from './playbook-content'
import { RegenerateSectionDialog } from './regenerate-section-dialog'
import type { Playbook } from '@/lib/types/database'

interface PlaybookViewerProps {
  playbook: Playbook & {
    current_version: any
  }
}

export function PlaybookViewer({ playbook }: PlaybookViewerProps) {
  const [activeSection, setActiveSection] = useState<string | null>(null)
  const [regenerateSection, setRegenerateSection] = useState<string | null>(null)

  const currentVersion = playbook.current_version
  const sections = currentVersion?.content?.sections || []

  const handleExportPDF = () => {
    // TODO: Implementar exportação PDF
    alert('Exportação PDF será implementada')
  }

  const formatDate = (date: string) => {
    return new Date(date).toLocaleDateString('pt-BR', {
      day: '2-digit',
      month: 'long',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    })
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="border-b border-border bg-card/50 backdrop-blur sticky top-0 z-10">
        <div className="mx-auto max-w-7xl px-4 py-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button variant="ghost" size="sm" asChild>
                <Link href="/dashboard">
                  <ArrowLeft className="mr-2 h-4 w-4" />
                  Dashboard
                </Link>
              </Button>
              <div className="h-6 w-px bg-border" />
              <div>
                <h1 className="text-xl font-bold">{playbook.title}</h1>
                <div className="flex items-center gap-3 mt-1">
                  <Badge variant="secondary" className="text-xs">
                    <BookOpen className="mr-1 h-3 w-3" />
                    Versão {currentVersion?.version_number || 1}
                  </Badge>
                  <span className="text-xs text-muted-foreground flex items-center gap-1">
                    <Clock className="h-3 w-3" />
                    {formatDate(playbook.updated_at)}
                  </span>
                </div>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <Button variant="outline" size="sm" onClick={handleExportPDF}>
                <Download className="mr-2 h-4 w-4" />
                Exportar PDF
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Main content */}
      <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Table of Contents - Sidebar */}
          <div className="lg:col-span-1">
            <div className="sticky top-24">
              <Card>
                <CardContent className="p-4">
                  <h2 className="font-semibold mb-4 text-sm uppercase tracking-wide text-muted-foreground">
                    Índice
                  </h2>
                  <PlaybookTableOfContents
                    sections={sections}
                    activeSection={activeSection}
                    onSectionClick={setActiveSection}
                  />
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Content */}
          <div className="lg:col-span-3">
            <PlaybookContent
              sections={sections}
              activeSection={activeSection}
              onRegenerateClick={setRegenerateSection}
            />
          </div>
        </div>
      </div>

      {/* Regenerate Dialog */}
      {regenerateSection && (
        <RegenerateSectionDialog
          playbookId={playbook.id}
          sectionId={regenerateSection}
          sectionTitle={
            sections.find((s: any) => s.id === regenerateSection)?.title || ''
          }
          onClose={() => setRegenerateSection(null)}
        />
      )}
    </div>
  )
}
