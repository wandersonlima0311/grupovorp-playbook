'use client'

import { useState } from 'react'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { useRouter } from 'next/navigation'
import { playbookInputSchema, type PlaybookInputFormData } from '@/lib/validation/schemas'
import { createPlaybook } from '@/app/actions/playbooks'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Progress } from '@/components/ui/progress'
import { ArrowLeft, ArrowRight, Sparkles } from 'lucide-react'
import { WizardStepNegocio } from './wizard-steps/step-negocio'
import { WizardStepPublico } from './wizard-steps/step-publico'
import { WizardStepProcesso } from './wizard-steps/step-processo'
import { WizardStepOperacao } from './wizard-steps/step-operacao'
import { WizardStepObjetivos } from './wizard-steps/step-objetivos'
import { Spinner } from '@/components/ui/spinner'

const STEPS = [
  { id: 1, title: 'Seu Negócio', description: 'Conte-nos sobre sua empresa' },
  { id: 2, title: 'Público-Alvo', description: 'Quem são seus clientes?' },
  { id: 3, title: 'Processo de Vendas', description: 'Como você vende?' },
  { id: 4, title: 'Operação', description: 'Estrutura e recursos' },
  { id: 5, title: 'Objetivos', description: 'Suas metas e prioridades' },
]

export function PlaybookWizard() {
  const router = useRouter()
  const [currentStep, setCurrentStep] = useState(1)
  const [isSubmitting, setIsSubmitting] = useState(false)

  const {
    register,
    handleSubmit,
    formState: { errors },
    trigger,
    watch,
  } = useForm<PlaybookInputFormData>({
    resolver: zodResolver(playbookInputSchema),
    mode: 'onChange',
  })

  const progress = (currentStep / STEPS.length) * 100

  const validateStep = async () => {
    const fieldsToValidate: Record<number, (keyof PlaybookInputFormData)[]> = {
      1: ['negocio'],
      2: ['publico'],
      3: ['processo'],
      4: ['operacao'],
      5: ['objetivos'],
    }

    const fields = fieldsToValidate[currentStep]
    return await trigger(fields)
  }

  const handleNext = async () => {
    const isValid = await validateStep()
    if (isValid && currentStep < STEPS.length) {
      setCurrentStep(currentStep + 1)
    }
  }

  const handleBack = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1)
    }
  }

  const onSubmit = async (data: PlaybookInputFormData) => {
    setIsSubmitting(true)

    // Gerar título baseado no setor
    const title = `Playbook ${data.negocio.setor} - ${new Date().toLocaleDateString('pt-BR')}`

    const result = await createPlaybook(data, title)

    if (result.error) {
      alert('Erro ao criar playbook: ' + result.error)
      setIsSubmitting(false)
      return
    }

    // Redirecionar para página de geração com IA
    if (result.data) {
      router.push(`/playbook/${result.data.id}/gerar`)
    }
  }

  const renderStep = () => {
    switch (currentStep) {
      case 1:
        return <WizardStepNegocio register={register} errors={errors} watch={watch} />
      case 2:
        return <WizardStepPublico register={register} errors={errors} watch={watch} />
      case 3:
        return <WizardStepProcesso register={register} errors={errors} watch={watch} />
      case 4:
        return <WizardStepOperacao register={register} errors={errors} watch={watch} />
      case 5:
        return <WizardStepObjetivos register={register} errors={errors} watch={watch} />
      default:
        return null
    }
  }

  return (
    <div className="mx-auto max-w-4xl px-4 py-8 sm:px-6 lg:px-8">
      <div className="mb-8">
        <Button variant="ghost" onClick={() => router.push('/dashboard')}>
          <ArrowLeft className="mr-2 h-4 w-4" />
          Voltar ao Dashboard
        </Button>
      </div>

      <div className="mb-8">
        <div className="flex items-center gap-3 mb-4">
          <div className="rounded-lg bg-primary/10 p-2">
            <Sparkles className="h-6 w-6 text-primary" />
          </div>
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Criar Novo Playbook</h1>
            <p className="text-muted-foreground">
              Etapa {currentStep} de {STEPS.length}: {STEPS[currentStep - 1].title}
            </p>
          </div>
        </div>
        <Progress value={progress} className="h-2" />
      </div>

      <form onSubmit={handleSubmit(onSubmit)}>
        <Card>
          <CardHeader>
            <CardTitle>{STEPS[currentStep - 1].title}</CardTitle>
            <CardDescription>{STEPS[currentStep - 1].description}</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            {renderStep()}
          </CardContent>
        </Card>

        <div className="mt-8 flex justify-between">
          <Button
            type="button"
            variant="outline"
            onClick={handleBack}
            disabled={currentStep === 1 || isSubmitting}
          >
            <ArrowLeft className="mr-2 h-4 w-4" />
            Anterior
          </Button>

          {currentStep < STEPS.length ? (
            <Button type="button" onClick={handleNext} disabled={isSubmitting}>
              Próximo
              <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          ) : (
            <Button type="submit" disabled={isSubmitting}>
              {isSubmitting && <Spinner className="mr-2" />}
              Gerar Playbook com IA
              <Sparkles className="ml-2 h-4 w-4" />
            </Button>
          )}
        </div>
      </form>
    </div>
  )
}
