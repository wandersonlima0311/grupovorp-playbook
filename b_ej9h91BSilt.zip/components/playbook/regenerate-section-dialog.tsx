'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import { Button } from '@/components/ui/button'
import { Textarea } from '@/components/ui/textarea'
import { Label } from '@/components/ui/label'
import { Spinner } from '@/components/ui/spinner'
import { regeneratePlaybookSection } from '@/app/actions/generate-playbook'

interface RegenerateSectionDialogProps {
  playbookId: string
  sectionId: string
  sectionTitle: string
  onClose: () => void
}

export function RegenerateSectionDialog({
  playbookId,
  sectionId,
  sectionTitle,
  onClose,
}: RegenerateSectionDialogProps) {
  const router = useRouter()
  const [instructions, setInstructions] = useState('')
  const [isRegenerating, setIsRegenerating] = useState(false)

  const handleRegenerate = async () => {
    setIsRegenerating(true)

    try {
      await regeneratePlaybookSection(
        playbookId,
        sectionId,
        instructions || undefined
      )
      router.refresh()
      onClose()
    } catch (error) {
      alert('Erro ao regenerar seção: ' + (error instanceof Error ? error.message : 'Erro desconhecido'))
    } finally {
      setIsRegenerating(false)
    }
  }

  return (
    <Dialog open onOpenChange={onClose}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>Regenerar Seção</DialogTitle>
          <DialogDescription>
            Regenere a seção <strong>{sectionTitle}</strong> com novas instruções ou
            deixe em branco para uma versão alternativa.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-4">
          <div className="space-y-2">
            <Label htmlFor="instructions">
              Instruções personalizadas (opcional)
            </Label>
            <Textarea
              id="instructions"
              placeholder="Ex: Adicione mais exemplos práticos, foque em estratégias de prospecção digital..."
              rows={5}
              value={instructions}
              onChange={(e) => setInstructions(e.target.value)}
              disabled={isRegenerating}
            />
            <p className="text-xs text-muted-foreground">
              Deixe em branco para regenerar com uma abordagem diferente mantendo a
              mesma qualidade.
            </p>
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={onClose} disabled={isRegenerating}>
            Cancelar
          </Button>
          <Button onClick={handleRegenerate} disabled={isRegenerating}>
            {isRegenerating && <Spinner className="mr-2" />}
            Regenerar Seção
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
