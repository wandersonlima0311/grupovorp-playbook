'use client'

import { useEffect, useRef } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { RefreshCw } from 'lucide-react'
import ReactMarkdown from 'react-markdown'
import remarkGfm from 'remark-gfm'

interface PlaybookContentProps {
  sections: Array<{ id: string; title: string; content: string }>
  activeSection: string | null
  onRegenerateClick: (sectionId: string) => void
}

export function PlaybookContent({
  sections,
  activeSection,
  onRegenerateClick,
}: PlaybookContentProps) {
  const sectionRefs = useRef<{ [key: string]: HTMLDivElement | null }>({})

  useEffect(() => {
    if (!activeSection) return

    const handleScroll = () => {
      const scrollPosition = window.scrollY + 200

      for (const section of sections) {
        const element = sectionRefs.current[section.id]
        if (element) {
          const { offsetTop, offsetHeight } = element
          if (
            scrollPosition >= offsetTop &&
            scrollPosition < offsetTop + offsetHeight
          ) {
            // Section is in view
            return
          }
        }
      }
    }

    window.addEventListener('scroll', handleScroll)
    return () => window.removeEventListener('scroll', handleScroll)
  }, [sections, activeSection])

  return (
    <div className="space-y-6">
      {sections.map((section, index) => (
        <div
          key={section.id}
          id={`section-${section.id}`}
          ref={(el) => {
            sectionRefs.current[section.id] = el
          }}
        >
          <Card className="scroll-mt-24">
            <CardHeader className="flex flex-row items-start justify-between space-y-0 pb-4">
              <div className="flex items-start gap-3">
                <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary/10 text-primary font-mono text-sm font-bold flex-shrink-0">
                  {String(index + 1).padStart(2, '0')}
                </div>
                <CardTitle className="text-2xl">{section.title}</CardTitle>
              </div>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => onRegenerateClick(section.id)}
              >
                <RefreshCw className="h-4 w-4 mr-2" />
                Regenerar
              </Button>
            </CardHeader>
            <CardContent>
              <div className="prose prose-slate dark:prose-invert max-w-none">
                <ReactMarkdown remarkPlugins={[remarkGfm]}>
                  {section.content}
                </ReactMarkdown>
              </div>
            </CardContent>
          </Card>
        </div>
      ))}

      {sections.length === 0 && (
        <Card>
          <CardContent className="py-16 text-center">
            <p className="text-muted-foreground">
              Nenhum conteúdo disponível ainda.
            </p>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
