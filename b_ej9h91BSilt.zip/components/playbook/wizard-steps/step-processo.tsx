import { UseFormRegister, FieldErrors, UseFormWatch } from 'react-hook-form'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import type { PlaybookInputFormData } from '@/lib/validation/schemas'

interface WizardStepProps {
  register: UseFormRegister<PlaybookInputFormData>
  errors: FieldErrors<PlaybookInputFormData>
  watch: UseFormWatch<PlaybookInputFormData>
}

export function WizardStepProcesso({ register, errors }: WizardStepProps) {
  return (
    <div className="space-y-6">
      <div className="space-y-2">
        <Label htmlFor="processo.etapas">
          Descreva as etapas do seu processo de vendas atual
          <span className="text-destructive ml-1">*</span>
        </Label>
        <Textarea
          id="processo.etapas"
          placeholder="Ex: Prospecção → Qualificação → Reunião → Proposta → Negociação → Fechamento..."
          rows={4}
          {...register('processo.etapas')}
        />
        {errors.processo?.etapas && (
          <p className="text-sm text-destructive">{errors.processo.etapas.message}</p>
        )}
      </div>

      <div className="space-y-2">
        <Label htmlFor="processo.ferramentas">
          Quais ferramentas e canais você utiliza?
          <span className="text-destructive ml-1">*</span>
        </Label>
        <Textarea
          id="processo.ferramentas"
          placeholder="Ex: CRM Pipedrive, LinkedIn, email marketing, WhatsApp Business..."
          rows={3}
          {...register('processo.ferramentas')}
        />
        {errors.processo?.ferramentas && (
          <p className="text-sm text-destructive">{errors.processo.ferramentas.message}</p>
        )}
      </div>

      <div className="space-y-2">
        <Label htmlFor="processo.metricas">
          Quais métricas você acompanha atualmente?
          <span className="text-destructive ml-1">*</span>
        </Label>
        <Textarea
          id="processo.metricas"
          placeholder="Ex: Taxa de conversão, ticket médio, tempo de ciclo, CAC, LTV..."
          rows={3}
          {...register('processo.metricas')}
        />
        {errors.processo?.metricas && (
          <p className="text-sm text-destructive">{errors.processo.metricas.message}</p>
        )}
      </div>
    </div>
  )
}
