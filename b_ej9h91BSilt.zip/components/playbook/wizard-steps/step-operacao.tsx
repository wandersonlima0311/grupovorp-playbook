import { UseFormRegister, FieldErrors, UseFormWatch } from 'react-hook-form'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import type { PlaybookInputFormData } from '@/lib/validation/schemas'

interface WizardStepProps {
  register: UseFormRegister<PlaybookInputFormData>
  errors: FieldErrors<PlaybookInputFormData>
  watch: UseFormWatch<PlaybookInputFormData>
}

export function WizardStepOperacao({ register, errors }: WizardStepProps) {
  return (
    <div className="space-y-6">
      <div className="space-y-2">
        <Label htmlFor="operacao.tamanho">
          Qual o tamanho da sua equipe comercial?
          <span className="text-destructive ml-1">*</span>
        </Label>
        <Textarea
          id="operacao.tamanho"
          placeholder="Ex: 1 gerente comercial, 3 vendedores, 2 SDRs..."
          rows={3}
          {...register('operacao.tamanho')}
        />
        {errors.operacao?.tamanho && (
          <p className="text-sm text-destructive">{errors.operacao.tamanho.message}</p>
        )}
      </div>

      <div className="space-y-2">
        <Label htmlFor="operacao.recursos">
          Quais recursos e orçamento você tem disponível?
          <span className="text-destructive ml-1">*</span>
        </Label>
        <Textarea
          id="operacao.recursos"
          placeholder="Ex: Orçamento de R$ 10k/mês para marketing, acesso a CRM, base de leads..."
          rows={4}
          {...register('operacao.recursos')}
        />
        {errors.operacao?.recursos && (
          <p className="text-sm text-destructive">{errors.operacao.recursos.message}</p>
        )}
      </div>

      <div className="space-y-2">
        <Label htmlFor="operacao.limitacoes">
          Quais são suas principais limitações operacionais?
          <span className="text-destructive ml-1">*</span>
        </Label>
        <Textarea
          id="operacao.limitacoes"
          placeholder="Ex: Equipe pequena, orçamento limitado, falta de expertise em digital..."
          rows={4}
          {...register('operacao.limitacoes')}
        />
        {errors.operacao?.limitacoes && (
          <p className="text-sm text-destructive">{errors.operacao.limitacoes.message}</p>
        )}
      </div>
    </div>
  )
}
