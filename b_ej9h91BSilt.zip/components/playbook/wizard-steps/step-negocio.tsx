import { UseFormRegister, FieldErrors, UseFormWatch } from 'react-hook-form'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import type { PlaybookInputFormData } from '@/lib/validation/schemas'

interface WizardStepProps {
  register: UseFormRegister<PlaybookInputFormData>
  errors: FieldErrors<PlaybookInputFormData>
  watch: UseFormWatch<PlaybookInputFormData>
}

export function WizardStepNegocio({ register, errors }: WizardStepProps) {
  return (
    <div className="space-y-6">
      <div className="space-y-2">
        <Label htmlFor="negocio.setor">
          Em qual setor sua empresa atua?
          <span className="text-destructive ml-1">*</span>
        </Label>
        <Textarea
          id="negocio.setor"
          placeholder="Ex: Tecnologia SaaS B2B, consultoria em marketing digital..."
          rows={3}
          {...register('negocio.setor')}
        />
        {errors.negocio?.setor && (
          <p className="text-sm text-destructive">{errors.negocio.setor.message}</p>
        )}
      </div>

      <div className="space-y-2">
        <Label htmlFor="negocio.modelo">
          Qual é o modelo de negócio?
          <span className="text-destructive ml-1">*</span>
        </Label>
        <Textarea
          id="negocio.modelo"
          placeholder="Ex: Assinatura mensal, venda consultiva de alto ticket, freemium..."
          rows={3}
          {...register('negocio.modelo')}
        />
        {errors.negocio?.modelo && (
          <p className="text-sm text-destructive">{errors.negocio.modelo.message}</p>
        )}
      </div>

      <div className="space-y-2">
        <Label htmlFor="negocio.diferenciais">
          Quais são seus principais diferenciais competitivos?
          <span className="text-destructive ml-1">*</span>
        </Label>
        <Textarea
          id="negocio.diferenciais"
          placeholder="Ex: Atendimento personalizado, tecnologia proprietária, expertise de 10 anos..."
          rows={4}
          {...register('negocio.diferenciais')}
        />
        {errors.negocio?.diferenciais && (
          <p className="text-sm text-destructive">{errors.negocio.diferenciais.message}</p>
        )}
      </div>

      <div className="space-y-2">
        <Label htmlFor="negocio.desafios">
          Quais são os principais desafios do seu mercado?
          <span className="text-destructive ml-1">*</span>
        </Label>
        <Textarea
          id="negocio.desafios"
          placeholder="Ex: Alta concorrência, ciclo de venda longo, necessidade de educar o mercado..."
          rows={4}
          {...register('negocio.desafios')}
        />
        {errors.negocio?.desafios && (
          <p className="text-sm text-destructive">{errors.negocio.desafios.message}</p>
        )}
      </div>
    </div>
  )
}
