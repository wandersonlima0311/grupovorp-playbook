import { UseFormRegister, FieldErrors, UseFormWatch } from 'react-hook-form'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import type { PlaybookInputFormData } from '@/lib/validation/schemas'

interface WizardStepProps {
  register: UseFormRegister<PlaybookInputFormData>
  errors: FieldErrors<PlaybookInputFormData>
  watch: UseFormWatch<PlaybookInputFormData>
}

export function WizardStepObjetivos({ register, errors }: WizardStepProps) {
  return (
    <div className="space-y-6">
      <div className="space-y-2">
        <Label htmlFor="objetivos.metas">
          Quais são suas principais metas comerciais?
          <span className="text-destructive ml-1">*</span>
        </Label>
        <Textarea
          id="objetivos.metas"
          placeholder="Ex: Aumentar faturamento em 30%, reduzir ciclo de venda, melhorar taxa de conversão..."
          rows={4}
          {...register('objetivos.metas')}
        />
        {errors.objetivos?.metas && (
          <p className="text-sm text-destructive">{errors.objetivos.metas.message}</p>
        )}
      </div>

      <div className="space-y-2">
        <Label htmlFor="objetivos.prazos">
          Em quanto tempo você quer alcançar essas metas?
          <span className="text-destructive ml-1">*</span>
        </Label>
        <Textarea
          id="objetivos.prazos"
          placeholder="Ex: 6 meses, 1 ano, Q2 2026..."
          rows={2}
          {...register('objetivos.prazos')}
        />
        {errors.objetivos?.prazos && (
          <p className="text-sm text-destructive">{errors.objetivos.prazos.message}</p>
        )}
      </div>

      <div className="space-y-2">
        <Label htmlFor="objetivos.prioridades">
          Quais são suas prioridades e expectativas para este playbook?
          <span className="text-destructive ml-1">*</span>
        </Label>
        <Textarea
          id="objetivos.prioridades"
          placeholder="Ex: Ter um processo estruturado, treinar a equipe, aumentar previsibilidade de resultados..."
          rows={4}
          {...register('objetivos.prioridades')}
        />
        {errors.objetivos?.prioridades && (
          <p className="text-sm text-destructive">{errors.objetivos.prioridades.message}</p>
        )}
      </div>
    </div>
  )
}
