import { UseFormRegister, FieldErrors, UseFormWatch } from 'react-hook-form'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import type { PlaybookInputFormData } from '@/lib/validation/schemas'

interface WizardStepProps {
  register: UseFormRegister<PlaybookInputFormData>
  errors: FieldErrors<PlaybookInputFormData>
  watch: UseFormWatch<PlaybookInputFormData>
}

export function WizardStepPublico({ register, errors }: WizardStepProps) {
  return (
    <div className="space-y-6">
      <div className="space-y-2">
        <Label htmlFor="publico.perfil">
          Descreva o perfil do seu cliente ideal (ICP)
          <span className="text-destructive ml-1">*</span>
        </Label>
        <Textarea
          id="publico.perfil"
          placeholder="Ex: Empresas de médio porte (50-200 funcionários), diretores de TI, orçamento de R$ 20-50k..."
          rows={4}
          {...register('publico.perfil')}
        />
        {errors.publico?.perfil && (
          <p className="text-sm text-destructive">{errors.publico.perfil.message}</p>
        )}
      </div>

      <div className="space-y-2">
        <Label htmlFor="publico.dores">
          Quais são as principais dores e necessidades deles?
          <span className="text-destructive ml-1">*</span>
        </Label>
        <Textarea
          id="publico.dores"
          placeholder="Ex: Processos manuais demorados, falta de visibilidade de dados, custos altos..."
          rows={4}
          {...register('publico.dores')}
        />
        {errors.publico?.dores && (
          <p className="text-sm text-destructive">{errors.publico.dores.message}</p>
        )}
      </div>

      <div className="space-y-2">
        <Label htmlFor="publico.objecoes">
          Quais objeções você costuma ouvir no processo de venda?
          <span className="text-destructive ml-1">*</span>
        </Label>
        <Textarea
          id="publico.objecoes"
          placeholder="Ex: 'Está muito caro', 'Preciso pensar', 'Já temos um fornecedor'..."
          rows={4}
          {...register('publico.objecoes')}
        />
        {errors.publico?.objecoes && (
          <p className="text-sm text-destructive">{errors.publico.objecoes.message}</p>
        )}
      </div>
    </div>
  )
}
