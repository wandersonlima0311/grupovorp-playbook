'use client'

import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import { generatePlaybook } from '@/app/actions/generate-playbook'
import { Card, CardContent } from '@/components/ui/card'
import { Progress } from '@/components/ui/progress'
import { Sparkles, CheckCircle2, Loader2 } from 'lucide-react'

const GENERATION_STEPS = [
  'Analisando informações do negócio...',
  'Identificando estratégias personalizadas...',
  'Estruturando processo de vendas...',
  'Criando scripts e templates...',
  'Definindo métricas e KPIs...',
  'Gerando plano de ação...',
  'Finalizando playbook...',
]

export default function GerarPlaybookPage({ params }: { params: { id: string } }) {
  const router = useRouter()
  const [currentStep, setCurrentStep] = useState(0)
  const [error, setError] = useState<string | null>(null)
  const [isComplete, setIsComplete] = useState(false)

  useEffect(() => {
    const generate = async () => {
      try {
        // Simular progresso
        const stepInterval = setInterval(() => {
          setCurrentStep((prev) => {
            if (prev < GENERATION_STEPS.length - 1) {
              return prev + 1
            }
            return prev
          })
        }, 2000)

        // Gerar playbook
        const result = await generatePlaybook(params.id)

        clearInterval(stepInterval)
        setCurrentStep(GENERATION_STEPS.length - 1)
        setIsComplete(true)

        // Redirecionar após 2 segundos
        setTimeout(() => {
          router.push(`/playbook/${params.id}`)
        }, 2000)
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Erro ao gerar playbook')
      }
    }

    generate()
  }, [params.id, router])

  const progress = ((currentStep + 1) / GENERATION_STEPS.length) * 100

  if (error) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background p-4">
        <Card className="w-full max-w-md">
          <CardContent className="pt-6">
            <div className="text-center">
              <div className="mb-4 inline-flex rounded-full bg-destructive/10 p-3">
                <Sparkles className="h-8 w-8 text-destructive" />
              </div>
              <h2 className="text-xl font-bold mb-2">Erro na Geração</h2>
              <p className="text-muted-foreground mb-4">{error}</p>
              <button
                onClick={() => router.push('/dashboard')}
                className="text-primary hover:underline"
              >
                Voltar ao Dashboard
              </button>
            </div>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-background p-4">
      <Card className="w-full max-w-2xl">
        <CardContent className="pt-8 pb-8">
          <div className="text-center mb-8">
            <div className="mb-4 inline-flex rounded-full bg-primary/10 p-4">
              {isComplete ? (
                <CheckCircle2 className="h-12 w-12 text-primary" />
              ) : (
                <Loader2 className="h-12 w-12 text-primary animate-spin" />
              )}
            </div>
            <h1 className="text-3xl font-bold mb-2">
              {isComplete ? 'Playbook Gerado!' : 'Gerando seu Playbook Comercial'}
            </h1>
            <p className="text-muted-foreground">
              {isComplete
                ? 'Redirecionando para visualização...'
                : 'Nossa IA está criando um playbook personalizado para você'}
            </p>
          </div>

          <div className="space-y-6">
            <Progress value={progress} className="h-3" />

            <div className="space-y-3">
              {GENERATION_STEPS.map((step, index) => (
                <div
                  key={index}
                  className={`flex items-center gap-3 p-3 rounded-lg transition-all ${
                    index <= currentStep
                      ? 'bg-primary/10 text-foreground'
                      : 'bg-muted/30 text-muted-foreground'
                  }`}
                >
                  {index < currentStep ? (
                    <CheckCircle2 className="h-5 w-5 text-primary flex-shrink-0" />
                  ) : index === currentStep ? (
                    <Loader2 className="h-5 w-5 text-primary animate-spin flex-shrink-0" />
                  ) : (
                    <div className="h-5 w-5 rounded-full border-2 border-muted-foreground/30 flex-shrink-0" />
                  )}
                  <span className="text-sm font-medium">{step}</span>
                </div>
              ))}
            </div>

            <div className="text-center text-sm text-muted-foreground pt-4">
              <Sparkles className="inline h-4 w-4 mr-1" />
              Aguarde enquanto criamos conteúdo personalizado baseado nas suas informações
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
