import { redirect } from 'next/navigation'
import { getPlaybookWithVersion } from '@/app/actions/playbook-viewer'
import { PlaybookViewer } from '@/components/playbook/playbook-viewer'

export default async function PlaybookPage({ params }: { params: { id: string } }) {
  const result = await getPlaybookWithVersion(params.id)

  if (result.error || !result.data) {
    redirect('/dashboard')
  }

  const playbook = result.data

  // Se ainda não foi gerado, redirecionar para página de geração
  if (playbook.status === 'draft' && !playbook.current_version_id) {
    redirect(`/playbook/${params.id}/gerar`)
  }

  return <PlaybookViewer playbook={playbook} />
}
