import { PlaybookWizard } from '@/components/playbook/playbook-wizard'

export default function NovoPlaybookPage() {
  return (
    <div className="min-h-screen bg-background">
      <PlaybookWizard />
    </div>
  )
}
