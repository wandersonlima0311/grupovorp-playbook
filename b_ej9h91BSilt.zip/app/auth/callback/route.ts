import { createClient } from '@/lib/supabase/server'
import { NextRequest, NextResponse } from 'next/server'

export async function GET(request: NextRequest) {
  const { searchParams, origin } = request.nextUrl
  const code = searchParams.get('code')

  if (code) {
    const supabase = await createClient()
    const { error } = await supabase.auth.exchangeCodeForSession(code)
    
    if (!error) {
      // Verificar se o usuário completou o onboarding
      const { data: { user } } = await supabase.auth.getUser()
      
      if (user) {
        const { data: metadata } = await supabase
          .from('users_metadata')
          .select('onboarding_completed')
          .eq('user_id', user.id)
          .single()

        // Se não completou onboarding, redirecionar para lá
        if (metadata && !metadata.onboarding_completed) {
          return NextResponse.redirect(`${origin}/cadastro/onboarding`)
        }
      }
      
      const next = searchParams.get('next') ?? '/dashboard'
      return NextResponse.redirect(`${origin}${next}`)
    }
  }

  return NextResponse.redirect(`${origin}/auth/error`)
}
