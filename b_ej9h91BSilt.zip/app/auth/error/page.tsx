import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { AlertCircle } from 'lucide-react'
import Link from 'next/link'

export default function AuthErrorPage() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-background p-4">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <div className="mx-auto mb-4 flex h-12 w-12 items-center justify-center rounded-full bg-destructive/10">
            <AlertCircle className="h-6 w-6 text-destructive" />
          </div>
          <CardTitle>Erro de Autenticação</CardTitle>
          <CardDescription>
            Ocorreu um erro ao processar sua autenticação. Por favor, tente novamente.
          </CardDescription>
        </CardHeader>
        <CardContent className="flex flex-col gap-2">
          <Button asChild>
            <Link href="/login">Voltar para Login</Link>
          </Button>
          <Button asChild variant="outline">
            <Link href="/cadastro">Criar Nova Conta</Link>
          </Button>
        </CardContent>
      </Card>
    </div>
  )
}
