'use server'

import { streamText } from 'ai'
import { createClient } from '@/lib/supabase/server'
import { buildPlaybookPrompt } from '@/lib/ai/prompts'
import type { PlaybookContent } from '@/lib/types/database'

export async function generatePlaybook(playbookId: string) {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()

  if (!user) {
    throw new Error('Usuário não autenticado')
  }

  // Buscar dados do playbook
  const { data: playbook, error: playbookError } = await supabase
    .from('playbooks')
    .select('*')
    .eq('id', playbookId)
    .eq('user_id', user.id)
    .single()

  if (playbookError || !playbook) {
    throw new Error('Playbook não encontrado')
  }

  // Gerar prompt
  const prompt = buildPlaybookPrompt(playbook.input_data)

  // Gerar conteúdo com IA
  const result = await streamText({
    model: 'anthropic/claude-opus-4.6',
    prompt,
    temperature: 0.7,
    maxTokens: 8000,
  })

  // Coletar todo o texto
  let fullText = ''
  for await (const chunk of result.textStream) {
    fullText += chunk
  }

  // Parse do JSON retornado
  let content: PlaybookContent
  try {
    // Extrair JSON do texto (pode vir com markdown)
    const jsonMatch = fullText.match(/\{[\s\S]*\}/)
    if (!jsonMatch) {
      throw new Error('Formato de resposta inválido')
    }
    content = JSON.parse(jsonMatch[0])
  } catch (error) {
    console.error('Erro ao fazer parse do JSON:', error)
    throw new Error('Erro ao processar resposta da IA')
  }

  // Criar versão do playbook
  const { data: version, error: versionError } = await supabase
    .from('playbook_versions')
    .insert({
      playbook_id: playbookId,
      version_number: 1,
      content,
      generation_prompt: prompt,
    })
    .select()
    .single()

  if (versionError) {
    throw new Error('Erro ao salvar versão do playbook')
  }

  // Atualizar playbook
  await supabase
    .from('playbooks')
    .update({
      status: 'completed',
      current_version_id: version.id,
    })
    .eq('id', playbookId)

  return { success: true, versionId: version.id }
}

export async function regeneratePlaybookSection(
  playbookId: string,
  sectionId: string,
  customInstructions?: string
) {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()

  if (!user) {
    throw new Error('Usuário não autenticado')
  }

  // Buscar playbook e versão atual
  const { data: playbook } = await supabase
    .from('playbooks')
    .select('*, playbook_versions(*)')
    .eq('id', playbookId)
    .eq('user_id', user.id)
    .single()

  if (!playbook) {
    throw new Error('Playbook não encontrado')
  }

  const currentVersion = playbook.playbook_versions?.[0]
  if (!currentVersion) {
    throw new Error('Versão não encontrada')
  }

  // Buscar informações da seção
  const section = currentVersion.content.sections.find((s: any) => s.id === sectionId)
  if (!section) {
    throw new Error('Seção não encontrada')
  }

  // Criar prompt para regenerar seção
  const basePrompt = buildPlaybookPrompt(playbook.input_data)
  const sectionPrompt = `${basePrompt}

IMPORTANTE: Regenere APENAS a seção "${section.title}" com as seguintes instruções adicionais:
${customInstructions || 'Mantenha o mesmo nível de qualidade, mas com uma abordagem diferente e mais exemplos práticos.'}

Retorne APENAS um JSON com a estrutura:
{
  "id": "${sectionId}",
  "title": "${section.title}",
  "content": "Novo conteúdo em Markdown aqui..."
}`

  // Gerar novo conteúdo
  const result = await streamText({
    model: 'anthropic/claude-opus-4.6',
    prompt: sectionPrompt,
    temperature: 0.8,
    maxTokens: 2000,
  })

  let fullText = ''
  for await (const chunk of result.textStream) {
    fullText += chunk
  }

  // Parse
  let newSection
  try {
    const jsonMatch = fullText.match(/\{[\s\S]*\}/)
    if (!jsonMatch) throw new Error('Formato inválido')
    newSection = JSON.parse(jsonMatch[0])
  } catch (error) {
    throw new Error('Erro ao processar resposta da IA')
  }

  // Atualizar conteúdo
  const updatedSections = currentVersion.content.sections.map((s: any) =>
    s.id === sectionId ? newSection : s
  )

  const newContent: PlaybookContent = {
    sections: updatedSections,
  }

  // Criar nova versão
  const { data: newVersion } = await supabase
    .from('playbook_versions')
    .insert({
      playbook_id: playbookId,
      version_number: currentVersion.version_number + 1,
      content: newContent,
      generation_prompt: sectionPrompt,
    })
    .select()
    .single()

  // Atualizar referência
  await supabase
    .from('playbooks')
    .update({ current_version_id: newVersion.id })
    .eq('id', playbookId)

  return { success: true, versionId: newVersion.id }
}
