'use server'

import { createClient } from '@/lib/supabase/server'
import type { PlaybookInputData } from '@/lib/types/database'

export async function getUserPlaybooks() {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()

  if (!user) {
    return { error: 'Usuário não autenticado' }
  }

  const { data, error } = await supabase
    .from('playbooks')
    .select('*')
    .eq('user_id', user.id)
    .order('updated_at', { ascending: false })

  if (error) {
    return { error: error.message }
  }

  return { data }
}

export async function getDashboardStats() {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()

  if (!user) {
    return { error: 'Usuário não autenticado' }
  }

  const { data: playbooks } = await supabase
    .from('playbooks')
    .select('*')
    .eq('user_id', user.id)

  const totalPlaybooks = playbooks?.length || 0
  const completedPlaybooks = playbooks?.filter(p => p.status === 'completed').length || 0
  const draftPlaybooks = playbooks?.filter(p => p.status === 'draft').length || 0

  return {
    data: {
      totalPlaybooks,
      completedPlaybooks,
      draftPlaybooks,
    }
  }
}

export async function createPlaybook(inputData: PlaybookInputData, title: string) {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()

  if (!user) {
    return { error: 'Usuário não autenticado' }
  }

  const { data, error } = await supabase
    .from('playbooks')
    .insert({
      user_id: user.id,
      title,
      status: 'draft',
      input_data: inputData,
    })
    .select()
    .single()

  if (error) {
    return { error: error.message }
  }

  return { data }
}

export async function deletePlaybook(playbookId: string) {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()

  if (!user) {
    return { error: 'Usuário não autenticado' }
  }

  const { error } = await supabase
    .from('playbooks')
    .delete()
    .eq('id', playbookId)
    .eq('user_id', user.id)

  if (error) {
    return { error: error.message }
  }

  return { success: true }
}
