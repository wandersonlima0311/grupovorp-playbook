'use server'

import { createClient } from '@/lib/supabase/server'

export async function getPlaybookWithVersion(playbookId: string) {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()

  if (!user) {
    return { error: 'Usuário não autenticado' }
  }

  const { data: playbook, error } = await supabase
    .from('playbooks')
    .select(`
      *,
      current_version:playbook_versions!current_version_id(*)
    `)
    .eq('id', playbookId)
    .eq('user_id', user.id)
    .single()

  if (error || !playbook) {
    return { error: 'Playbook não encontrado' }
  }

  return { data: playbook }
}

export async function getPlaybookVersions(playbookId: string) {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()

  if (!user) {
    return { error: 'Usuário não autenticado' }
  }

  // Verificar se o playbook pertence ao usuário
  const { data: playbook } = await supabase
    .from('playbooks')
    .select('id')
    .eq('id', playbookId)
    .eq('user_id', user.id)
    .single()

  if (!playbook) {
    return { error: 'Playbook não encontrado' }
  }

  const { data: versions, error } = await supabase
    .from('playbook_versions')
    .select('*')
    .eq('playbook_id', playbookId)
    .order('version_number', { ascending: false })

  if (error) {
    return { error: error.message }
  }

  return { data: versions }
}
