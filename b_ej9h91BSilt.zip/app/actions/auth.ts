'use server'

import { createClient } from '@/lib/supabase/server'
import { revalidatePath } from 'next/cache'
import { redirect } from 'next/navigation'
import type { LoginFormData, SignupFormData, OnboardingFormData } from '@/lib/validation/schemas'

export async function login(data: LoginFormData) {
  const supabase = await createClient()

  const { error } = await supabase.auth.signInWithPassword({
    email: data.email,
    password: data.password,
  })

  if (error) {
    return { error: error.message }
  }

  revalidatePath('/', 'layout')
  redirect('/dashboard')
}

export async function signup(data: SignupFormData) {
  const supabase = await createClient()

  const { error } = await supabase.auth.signUp({
    email: data.email,
    password: data.password,
    options: {
      emailRedirectTo: process.env.NEXT_PUBLIC_DEV_SUPABASE_REDIRECT_URL ?? 
        `${process.env.NEXT_PUBLIC_SITE_URL}/auth/callback`,
    },
  })

  if (error) {
    return { error: error.message }
  }

  // O registro em users_metadata é criado automaticamente via trigger do banco de dados
  // Redirecionar para página de sucesso pedindo verificação de email
  revalidatePath('/', 'layout')
  redirect('/cadastro/sucesso')
}

export async function logout() {
  const supabase = await createClient()
  await supabase.auth.signOut()
  revalidatePath('/', 'layout')
  redirect('/login')
}

export async function completeOnboarding(data: OnboardingFormData) {
  const supabase = await createClient()

  const { data: { user } } = await supabase.auth.getUser()

  if (!user) {
    return { error: 'Usuário não autenticado' }
  }

  const { error } = await supabase
    .from('users_metadata')
    .update({
      company_name: data.companyName,
      role: data.role,
      industry: data.industry,
      company_size: data.companySize,
      onboarding_completed: true,
    })
    .eq('user_id', user.id)

  if (error) {
    return { error: 'Erro ao salvar informações' }
  }

  revalidatePath('/', 'layout')
  redirect('/dashboard')
}

export async function getCurrentUser() {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  
  if (!user) return null

  const { data: metadata } = await supabase
    .from('users_metadata')
    .select('*')
    .eq('user_id', user.id)
    .single()

  return {
    ...user,
    metadata,
  }
}
