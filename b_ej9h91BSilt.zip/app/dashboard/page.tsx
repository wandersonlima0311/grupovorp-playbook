import { redirect } from 'next/navigation'
import { getCurrentUser } from '@/app/actions/auth'
import { getDashboardStats, getUserPlaybooks } from '@/app/actions/playbooks'
import { DashboardHeader } from '@/components/dashboard/dashboard-header'
import { DashboardStats } from '@/components/dashboard/dashboard-stats'
import { PlaybooksList } from '@/components/dashboard/playbooks-list'
import { EmptyState } from '@/components/dashboard/empty-state'

export default async function DashboardPage() {
  const user = await getCurrentUser()

  if (!user) {
    redirect('/login')
  }

  const statsResult = await getDashboardStats()
  const playbooksResult = await getUserPlaybooks()

  const stats = statsResult.data || { totalPlaybooks: 0, completedPlaybooks: 0, draftPlaybooks: 0 }
  const playbooks = playbooksResult.data || []

  return (
    <div className="min-h-screen bg-background">
      <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
        <DashboardHeader user={user} />
        
        <div className="mt-8">
          <DashboardStats stats={stats} />
        </div>

        <div className="mt-12">
          {playbooks.length > 0 ? (
            <PlaybooksList playbooks={playbooks} />
          ) : (
            <EmptyState />
          )}
        </div>
      </div>
    </div>
  )
}
