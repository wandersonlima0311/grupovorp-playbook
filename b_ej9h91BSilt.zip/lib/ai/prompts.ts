import type { PlaybookInputData } from '@/lib/types/database'

export function buildPlaybookPrompt(inputData: PlaybookInputData): string {
  return `Você é um consultor comercial especialista em criar playbooks de vendas personalizados. 

Com base nas informações fornecidas pelo cliente, crie um playbook comercial completo, estruturado e acionável.

## INFORMAÇÕES DO CLIENTE:

### Negócio:
- Setor: ${inputData.negocio.setor}
- Modelo de negócio: ${inputData.negocio.modelo}
- Diferenciais: ${inputData.negocio.diferenciais}
- Desafios: ${inputData.negocio.desafios}

### Público-alvo:
- Perfil ICP: ${inputData.publico.perfil}
- Dores principais: ${inputData.publico.dores}
- Objeções comuns: ${inputData.publico.objecoes}

### Processo de vendas:
- Etapas atuais: ${inputData.processo.etapas}
- Ferramentas utilizadas: ${inputData.processo.ferramentas}
- Métricas acompanhadas: ${inputData.processo.metricas}

### Operação:
- Tamanho da equipe: ${inputData.operacao.tamanho}
- Recursos disponíveis: ${inputData.operacao.recursos}
- Limitações: ${inputData.operacao.limitacoes}

### Objetivos:
- Metas: ${inputData.objetivos.metas}
- Prazos: ${inputData.objetivos.prazos}
- Prioridades: ${inputData.objetivos.prioridades}

## INSTRUÇÕES:

Gere um playbook completo em formato Markdown com as seguintes 12 seções obrigatórias:

1. **Visão Geral do Negócio**: Análise do modelo de negócio, posicionamento e diferenciais competitivos
2. **Perfil do Cliente Ideal (ICP)**: Definição detalhada do cliente ideal, incluindo características demográficas, comportamentais e necessidades
3. **Proposta de Valor**: Como articular os diferenciais para o ICP, conectando soluções às dores
4. **Estratégia de Prospecção**: Canais, táticas e scripts de abordagem inicial
5. **Processo de Qualificação**: Framework para qualificar leads (BANT, GPCT, etc.) com perguntas-chave
6. **Condução de Reuniões**: Estrutura de reuniões de descoberta e apresentação, incluindo roteiro e técnicas
7. **Tratamento de Objeções**: Scripts e estratégias para lidar com cada objeção comum identificada
8. **Apresentação de Proposta**: Como estruturar e apresentar propostas comerciais de alto impacto
9. **Negociação e Fechamento**: Táticas de negociação, sinais de compra e técnicas de fechamento
10. **Métricas e KPIs**: Indicadores-chave para acompanhar e metas sugeridas
11. **Plano de Ação 90 Dias**: Roadmap prático com ações prioritárias para os próximos 3 meses
12. **Scripts e Templates**: Modelos prontos de emails, mensagens e scripts de vendas

## FORMATO DE SAÍDA:

Retorne APENAS um JSON válido com a seguinte estrutura:

{
  "sections": [
    {
      "id": "visao-geral",
      "title": "Visão Geral do Negócio",
      "content": "Conteúdo em Markdown aqui..."
    },
    {
      "id": "perfil-icp",
      "title": "Perfil do Cliente Ideal (ICP)",
      "content": "Conteúdo em Markdown aqui..."
    }
    // ... todas as 12 seções
  ]
}

IMPORTANTE:
- Cada seção deve ter conteúdo RICO, DETALHADO e ESPECÍFICO para o contexto do cliente
- Use Markdown para formatação: headers (##, ###), listas, tabelas, negrito, etc.
- Seja PRÁTICO e ACIONÁVEL - evite teorias genéricas
- Adapte todas as recomendações aos recursos e limitações mencionados
- Inclua exemplos e scripts específicos para o setor e modelo de negócio
- O conteúdo deve ter qualidade consultiva profissional

Gere o playbook agora:`
}

export const PLAYBOOK_SECTIONS = [
  { id: 'visao-geral', title: 'Visão Geral do Negócio' },
  { id: 'perfil-icp', title: 'Perfil do Cliente Ideal (ICP)' },
  { id: 'proposta-valor', title: 'Proposta de Valor' },
  { id: 'estrategia-prospeccao', title: 'Estratégia de Prospecção' },
  { id: 'processo-qualificacao', title: 'Processo de Qualificação' },
  { id: 'conducao-reunioes', title: 'Condução de Reuniões' },
  { id: 'tratamento-objecoes', title: 'Tratamento de Objeções' },
  { id: 'apresentacao-proposta', title: 'Apresentação de Proposta' },
  { id: 'negociacao-fechamento', title: 'Negociação e Fechamento' },
  { id: 'metricas-kpis', title: 'Métricas e KPIs' },
  { id: 'plano-acao', title: 'Plano de Ação 90 Dias' },
  { id: 'scripts-templates', title: 'Scripts e Templates' },
]
