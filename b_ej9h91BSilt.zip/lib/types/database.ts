export interface UserMetadata {
  id: string
  user_id: string
  company_name: string
  role: string
  industry: string
  company_size: string
  onboarding_completed: boolean
  created_at: string
  updated_at: string
}

export interface Playbook {
  id: string
  user_id: string
  title: string
  status: 'draft' | 'completed'
  current_version_id: string | null
  input_data: PlaybookInputData
  created_at: string
  updated_at: string
}

export interface PlaybookInputData {
  negocio: {
    setor: string
    modelo: string
    diferenciais: string
    desafios: string
  }
  publico: {
    perfil: string
    dores: string
    objecoes: string
  }
  processo: {
    etapas: string
    ferramentas: string
    metricas: string
  }
  operacao: {
    tamanho: string
    recursos: string
    limitacoes: string
  }
  objetivos: {
    metas: string
    prazos: string
    prioridades: string
  }
}

export interface PlaybookVersion {
  id: string
  playbook_id: string
  version_number: number
  content: PlaybookContent
  generation_prompt: string
  created_at: string
}

export interface PlaybookContent {
  sections: {
    id: string
    title: string
    content: string
  }[]
}
