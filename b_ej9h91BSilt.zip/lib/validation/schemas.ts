import { z } from 'zod'

export const onboardingSchema = z.object({
  companyName: z.string().min(2, 'Nome da empresa deve ter pelo menos 2 caracteres'),
  role: z.string().min(2, 'Cargo deve ter pelo menos 2 caracteres'),
  industry: z.string().min(2, 'Selecione um setor'),
  companySize: z.string().min(1, 'Selecione o tamanho da empresa'),
})

export const loginSchema = z.object({
  email: z.string().email('Email inválido'),
  password: z.string().min(6, 'Senha deve ter pelo menos 6 caracteres'),
})

export const signupSchema = z.object({
  email: z.string().email('Email inválido'),
  password: z.string().min(6, 'Senha deve ter pelo menos 6 caracteres'),
  confirmPassword: z.string(),
}).refine((data) => data.password === data.confirmPassword, {
  message: 'As senhas não coincidem',
  path: ['confirmPassword'],
})

export const playbookInputSchema = z.object({
  negocio: z.object({
    setor: z.string().min(10, 'Descreva seu setor com mais detalhes'),
    modelo: z.string().min(10, 'Descreva seu modelo de negócio'),
    diferenciais: z.string().min(10, 'Descreva seus diferenciais'),
    desafios: z.string().min(10, 'Descreva seus desafios'),
  }),
  publico: z.object({
    perfil: z.string().min(10, 'Descreva o perfil do seu público'),
    dores: z.string().min(10, 'Descreva as dores do seu público'),
    objecoes: z.string().min(10, 'Descreva as objeções comuns'),
  }),
  processo: z.object({
    etapas: z.string().min(10, 'Descreva as etapas do seu processo'),
    ferramentas: z.string().min(5, 'Liste as ferramentas que usa'),
    metricas: z.string().min(10, 'Descreva suas métricas'),
  }),
  operacao: z.object({
    tamanho: z.string().min(5, 'Descreva o tamanho da equipe'),
    recursos: z.string().min(10, 'Descreva seus recursos'),
    limitacoes: z.string().min(10, 'Descreva suas limitações'),
  }),
  objetivos: z.object({
    metas: z.string().min(10, 'Descreva suas metas'),
    prazos: z.string().min(5, 'Descreva seus prazos'),
    prioridades: z.string().min(10, 'Descreva suas prioridades'),
  }),
})

export type OnboardingFormData = z.infer<typeof onboardingSchema>
export type LoginFormData = z.infer<typeof loginSchema>
export type SignupFormData = z.infer<typeof signupSchema>
export type PlaybookInputFormData = z.infer<typeof playbookInputSchema>
